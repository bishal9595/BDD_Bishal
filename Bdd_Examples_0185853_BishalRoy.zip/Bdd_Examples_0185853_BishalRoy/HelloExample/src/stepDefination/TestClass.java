package stepDefination;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	
	@Given("^User is on Home page$")
	public void user_is_on_Home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User is on Home page");
	}

	@When("^User clicks on the submit box$")
	public void user_clicks_on_the_submit_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("When user clicks on the submit box");
		
	}

	@Then("^it shows an \"([^\"]*)\" message\\.$")
	public void it_shows_an_message(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Then it shows an "+arg1+" message.");
	
		
}}
