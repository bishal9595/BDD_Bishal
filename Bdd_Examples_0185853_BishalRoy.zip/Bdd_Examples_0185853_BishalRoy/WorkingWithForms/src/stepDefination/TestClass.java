package stepDefination;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	
	@Given("^User is on Email Registration Page$")
	public void user_is_on_Email_Registration_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("User is on Email Registration Page");
	}

	@When("^User will forget to enter username$")
	public void user_will_forget_to_enter_username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("User will forget to enter username");
	}

	@Then("^Registration Form will not be Accepted\\.$")
	public void registration_Form_will_not_be_Accepted() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("Registration Form will not be Accepted");	}

	@When("^Password and confirm Password are different\\.$")
	public void password_and_confirm_Password_are_different() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("Password and confirm Password are different");
	}

	@Then("^Message will display Passwords donot match!$")
	public void message_will_display_Passwords_donot_match() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("Message will display Passwords donot match!");
	}

	@When("^User will forget to enter FirstName and LastName$")
	public void user_will_forget_to_enter_FirstName_and_LastName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("User will forget to enter FirstName and LastName");
	}

	@When("^User will forget to select Gender$")
	public void user_will_forget_to_select_Gender() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("User will forget to select Gender");
	}

	@When("^User will forget to enter BirthDate, Email and Address$")
	public void user_will_forget_to_enter_BirthDate_Email_and_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("User will forget to enter BirthDate, Email and Address");
	}

	@When("^User will forget to select city$")
	public void user_will_forget_to_select_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("User will forget to select city");
	}

	@When("^User will forget to enter PhoneNumber$")
	public void user_will_forget_to_enter_PhoneNumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("User will forget to enter PhoneNumber");
	}

	@When("^User will forget to select Hobbies$")
	public void user_will_forget_to_select_Hobbies() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("User is on Email Registration Page");
	}
	@Given("^User is on Registration Page$")
	public void user_is_on_Registration_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User is on the Registration Page");
	}

	@When("^User correctly enters every fields$")
	public void user_correctly_enters_every_fields() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User correctly enters every fields");
	}

	@When("^User clicks on submit button$")
	public void user_clicks_on_submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("User clicks on submit button");
	}

	@Then("^it displays \"([^\"]*)\"\\.$")
	public void it_displays(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Displays: "+arg1);
	}
	@When("^User clicks on \"([^\"]*)\" button$")
	public void user_clicks_on_button(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("When user clicks on: "+arg1+" button");
	}

	@Then("^all the fiels in the form gets reset and blanked\\.$")
	public void all_the_fiels_in_the_form_gets_reset_and_blanked() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Then all the fiels in the form gets reset and blanked");
	}

	
	
		
}
