package stepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		FirefoxOptions options = new FirefoxOptions();
		options.setCapability("marionette", false);
		WebDriver driver = new FirefoxDriver(options);

		driver.get("file:///D:/html/WorkingWithForms.html");
		WebElement element1=driver.findElement(By.id("txtUserName"));

 element1.sendKeys("bisharoy");



 WebElement element2=driver.findElement(By.id("txtPassword"));

 element2.sendKeys("capgemini1234");



 WebElement element3=driver.findElement(By.id("txtConfPassword"));

 element3.sendKeys("capgemini1234");



 WebElement element4=driver.findElement(By.id("rbMale"));

 element4.click();



 WebElement element5=driver.findElement(By.id("txtAddress"));

 element5.sendKeys("Hinjewadi");



 WebElement element6=driver.findElement(By.id("txtPhone"));

 element6.sendKeys("7777777777");



 WebElement element7=driver.findElement(By.name("City"));

 element7.sendKeys("Pune");



 WebElement element8=driver.findElement(By.id("m"));

 element8.click();



 WebElement element13=driver.findElement(By.id("mv"));

 element13.click();



 WebElement element9=driver.findElement(By.id("txtFirstName"));

 element9.sendKeys("Bishal");



 WebElement element10=driver.findElement(By.id("txtLastName"));

 element10.sendKeys("Roy");



 WebElement element11=driver.findElement(By.id("DOB"));

 element11.sendKeys("1/2/95");



 WebElement element12=driver.findElement(By.id("txtEmail"));

 element12.sendKeys("bishal123@gmail.com");
		Thread.sleep(10000);
		driver.quit();
	}

}
