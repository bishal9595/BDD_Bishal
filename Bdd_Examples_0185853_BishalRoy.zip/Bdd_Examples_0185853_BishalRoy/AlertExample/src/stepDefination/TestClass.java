package stepDefination;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	
	@Given("^User is on alert page$")
	public void user_is_on_alert_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User is on alert page");
	}

	@When("^User clicks on alert box$")
	public void user_clicks_on_alert_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User clicks on alert box");
	}

	@Then("^it shows an alert message\\.$")
	public void it_should_show_an_alert_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Clicking on box shows an alert message");
		
}}
