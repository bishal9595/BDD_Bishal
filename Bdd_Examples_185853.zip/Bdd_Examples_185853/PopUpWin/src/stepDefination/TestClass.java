package stepDefination;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	
	@Given("^User is on Home page having \"([^\"]*)\" button$")
	public void user_is_on_Home_page_having_button(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Given User is on home page having "+arg1+" button.");
	}

	@When("^User clicks on the button$")
	public void user_clicks_on_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("When user clicks on the button");
		
	}

	@Then("^it redirects to \"([^\"]*)\"\\.$")
	public void it_redirects_to(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();	
		System.out.println("Then it redirects to "+arg1);
		
}}
