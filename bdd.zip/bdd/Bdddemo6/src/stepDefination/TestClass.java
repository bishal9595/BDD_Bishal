package stepDefination;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	@Given("^I have a calculator$")
	public void i_have_a_calculator() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("calculator");
	}
	

	@When("^I add -(\\d+) & (\\d+)$")
	public void i_add1(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("added"+arg1+"and"+arg2);
	}

	@Then("^the rsult should be (\\d+)$")
	public void the_rsult_should_be(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("result:"+arg1);
	}

	@When("^I add (\\d+) & (\\d+)$")
	public void i_add2(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("added"+arg1+"and"+arg2);
	}

	@When("^I add (\\d+) & -(\\d+)$")
	public void i_add3(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("added"+arg1+"and"+arg2);
	}

	@When("^I add -(\\d+) & -(\\d+)$")
	public void i_add4(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("added"+arg1+"and"+arg2);
	}

	@Then("^the rsult should be -(\\d+)$")
	public void the_rsult_should_be1(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("result:"+arg1);
	}
	}



