package stepDefination;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
//@CucumberOptions(features= {"src/test/java/showProduct"},glue= {"src/test/java/stepDefination"},plugin= {"pretty"},dryRun=true)
//@CucumberOptions(features= {"src/test/java/showProduct"},glue= {"src/test/java/stepDefination"},format= {"pretty"},dryRun=true)
@CucumberOptions(features= {"src/test/java/showProduct"},glue= {"stepDefination"})
public class TestRunner {

}
