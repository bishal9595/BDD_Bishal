package stepDefination;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	
	@Given("^I have a Login Page$")
	public void i_have_a_Login_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Welcome to Facebook login Page:");
	}

	@When("^I pass \"([^\"]*)\" & \"([^\"]*)\"$")
	public void i_pass(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Username:"+arg1+" Password:"+arg2);
	}

	@Then("^the result should be \"([^\"]*)\"$")
	public void the_result_should_be(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Result:"+arg1);
	}
	
	
	}



